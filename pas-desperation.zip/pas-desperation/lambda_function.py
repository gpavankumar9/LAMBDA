import awscam
import cv2
import boto3
import json
from threading import Thread, Event
import datetime
import os
import json
import numpy as np
import awscam
import cv2
import sys
from pprint import pprint
import warnings

#pavan lambda cicd

warnings.filterwarnings('ignore')
client = boto3.client('runtime.sagemaker', region_name='us-east-1', aws_access_key_id='AKIA5OBWNLD7MFB4GDN6', aws_secret_access_key='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')

class LocalDisplay(Thread):
    def __init__(self, resolution):
        super(LocalDisplay, self).__init__()
        RESOLUTION = {'1080p' : (1920, 1080), '720p' : (1280, 720), '480p' : (640, 480)}
        if resolution not in RESOLUTION:
            raise Exception("Invalid resolution")
        self.resolution = RESOLUTION[resolution]
        self.frame = cv2.imencode('.jpg', 255*np.ones([640, 480, 3]))[1]
        self.stop_request = Event()

    def run(self):
        """ Overridden method that continually dumps images to the desired
            FIFO file.
        """
        # Path to the FIFO file. The lambda only has permissions to the tmp
        # directory. Pointing to a FIFO file in another directory
        # will cause the lambda to crash.
        result_path = '/tmp/results.mjpeg'
        # Create the FIFO file if it doesn't exist.
        if not os.path.exists(result_path):
            os.mkfifo(result_path)
        # This call will block until a consumer is available
        with open(result_path, 'w') as fifo_file:
            while not self.stop_request.isSet():
                try:
                    # Write the data to the FIFO file. This call will block
                    # meaning the code will come to a halt here until a consumer
                    # is available.
                    fifo_file.write(self.frame.tobytes())
                except IOError:
                    continue

    def set_frame_data(self, frame):
        """ Method updates the image data. This currently encodes the
            numpy array to jpg but can be modified to support other encodings.
            frame - Numpy array containing the image data of the next frame
                    in the project stream.
        """
        ret, jpeg = cv2.imencode('.jpg', cv2.resize(frame, self.resolution))
        if not ret:
            raise Exception('Failed to set frame data')
        self.frame = jpeg

    def join(self):
        self.stop_request.set()


def greengrass_infinite_infer_run():
    local_display = LocalDisplay('720p')
    local_display.start()
    
    points_x = []
    points_y = []
    while(True):
    
        ret, frame = awscam.getLastFrame()
    
        cv2.imwrite("/tmp/frame.jpg", frame)
        img = cv2.imread('/tmp/frame.jpg')
        with open('/tmp/frame.jpg', 'rb') as f:
            payload = f.read()
    
        time_now=datetime.datetime.now().strftime("%d-%m-%Y__%H_%M_%S")
        predictions = client.invoke_endpoint(EndpointName='desperation-endpoint', Body=payload)
        time_now=datetime.datetime.now().strftime("%d-%m-%Y__%H_%M_%S")
        my_json = predictions['Body'].read().decode('utf8').replace("'", '"')
        predictions = json.loads(my_json)
    
        balls=[]
        imh, imw, rand = img.shape
        for prediction in predictions['prediction']:
            if prediction[1] > 0.2:
                balls.append(prediction)
                points_x.append(((prediction[2] + prediction[4]) / 2) * imw)
                points_y.append(((prediction[3] + prediction[5]) / 2) * imh)
    
        print img.shape
        
        print("balls : "+str(balls))
    
        print(datetime.datetime.now().strftime("%d-%m-%Y__%H_%M_%S"))
        if len(balls) > 0:
            for batch_data in balls:
                print batch_data
                class_id, confidence, xmin, ymin, xmax, ymax = batch_data
                height = int((ymax-ymin)*imh)
                width = int((xmax-xmin)*imw)
                x = int(xmin*imw)
                y = int(ymin*imh)
                print(x)
                print(y)
                print(x+width)
                print(y+height)
                cv2.rectangle(img, (x, y), (x+width, y+height), (0, 255, 0), 12)
    
                #drawing lines here
                z = zip(points_x, points_y)
                for i in range(0, len(points_x)):
                    if i > 0:
                        cv2.line(img, (int(z[i-1][0]), int(z[i-1][1])), (int(z[i][0]), int(z[i][1])), (0, 0, 255), 12)
                    else:
                        cv2.circle(img, (int(z[i][0]), int(z[i][1])), 2, (0, 0, 255), thickness = 12)
        local_display.set_frame_data(img)
        
# Execute the function above
greengrass_infinite_infer_run()


# This is a dummy handler and will not be invoked
# Instead the code above will be executed in an infinite loop for our example
def function_handler(event, context):
    return